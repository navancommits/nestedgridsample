using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void ParentGridView_OnRowEditing(object sender, GridViewEditEventArgs e)
    {
        int parent_index = e.NewEditIndex;
        
        //to set the edit index of the Parent grid with that of the current row
        ParentGridView.EditIndex = parent_index;
        ParentGridView.DataBind();
        //find the pubid_lbl containing pub_id in that particular row by using findcontrol method
        GridViewRow row = ParentGridView.Rows[parent_index];
        Label pub_id_lbl = (Label)row.FindControl("pubid_lbl");
       
        //save pub_id and edit_index in session for childgridview's use
        Session["PubID"] = Convert.ToInt32(pub_id_lbl.Text);
        Session["ParentGridViewIndex"] = parent_index;

   }
    protected void ChildGridView_OnRowEditing(object sender, GridViewEditEventArgs e)
    {

        //set the edit index of the child gridview with that of the current row
        int parent_index =(int)Session["ParentGridViewIndex"];
        GridViewRow parent_row = ParentGridView.Rows[parent_index];
        GridView ChildGridiView = (GridView)parent_row.FindControl("ChildGridView");

        int child_index = e.NewEditIndex;
        ChildGridiView.EditIndex = child_index;
        ChildGridiView.DataBind();
        //find the titleid_lbl in that particular row by using findcontrol method
        GridViewRow child_row = ChildGridiView.Rows[child_index];
        Label titleid_lbl = (Label)child_row.FindControl("titleid_lbl");
        // save the title_id in session for grandchildgridview's use
        Session["TitleID"] = titleid_lbl.Text;
    }
}
