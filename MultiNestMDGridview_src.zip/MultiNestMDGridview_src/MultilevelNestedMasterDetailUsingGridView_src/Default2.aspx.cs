﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
   
    string conString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        string sQuery = "SELECT S_id,S_code,S_name from India_state";
        GridState.DataSource = getData(sQuery);
        GridState.DataBind();

    }
    protected void GridState_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string S_id = GridState.DataKeys[e.Row.RowIndex].Value.ToString();
            string sQuery = "SELECT City_code,City_name,S_id FROM City  WHERE S_id='" + S_id + "'";
            GridView SC = (GridView)e.Row.FindControl("GridCity");
            SC.DataSource = getData(sQuery);
            SC.DataBind();
        }
    }
    private DataTable getData(string sQuery)
    {
        SqlDataAdapter sdt = new SqlDataAdapter();
        DataTable dTable = new DataTable();
        SqlConnection con = new SqlConnection(conString);
        con.Open();
        SqlCommand cmd = new SqlCommand(sQuery, con);
        sdt.SelectCommand = cmd;
        sdt.Fill(dTable);
        con.Close();
        return dTable;
    }

}